# Diabetes Risk Prediction

A machine learning pipeline to predict whether a patient is at risk of diabetes using key health metrics like glucose, insulin, BMI, etc.

## Features
- Logistic Regression, Random Forest, XGBoost
- ROC, Confusion Matrix, Classification Report
- SHAP Explainability
- Modular Codebase

## Run Instructions
```bash
pip install -r requirements.txt
python run_pipeline.py
