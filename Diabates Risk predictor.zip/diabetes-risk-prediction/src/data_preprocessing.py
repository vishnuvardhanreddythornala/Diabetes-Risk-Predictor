import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

def load_data(filepath):
    return pd.read_csv(filepath)
# ... your preprocess_data here (already robust as posted above)

def preprocess_data(df):
    features = [
        "Pregnancies", "Glucose", "BloodPressure", "SkinThickness",
        "Insulin", "BMI", "DiabetesPedigreeFunction", "Age"
    ]
    df = df[features + ["Outcome"]].copy()  # <- new: make a full copy to avoid chained assignment problems

    # Handle missing values (impute NaNs with column median)
    df = df.fillna(df.median())

    # Replace 0s in specific columns that cannot be zero
    for col in ["Glucose", "BloodPressure", "SkinThickness", "Insulin", "BMI"]:
        df.loc[:, col] = df[col].replace(0, df[col].median())

    # Outlier detection and capping using IQR
    for col in features:
        Q1 = df[col].quantile(0.25)
        Q3 = df[col].quantile(0.75)
        IQR = Q3 - Q1
        lower = Q1 - 1.5 * IQR
        upper = Q3 + 1.5 * IQR
        df.loc[:, col] = df[col].clip(lower, upper)

    X = df[features]
    y = df["Outcome"]

    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    X_train, X_test, y_train, y_test = train_test_split(
        X_scaled, y, test_size=0.2, random_state=42
    )

    return X_train, X_test, y_train, y_test, scaler