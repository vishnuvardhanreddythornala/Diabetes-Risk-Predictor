import streamlit as st
import numpy as np
import joblib

# Load trained model and scaler
model = joblib.load("models/best_model.pkl")
scaler = joblib.load("models/scaler.pkl")

st.title("🩺 Diabetes Risk Predictor")
st.markdown("Enter the patient information to predict the risk of diabetes.")

features = [
    "Pregnancies", "Glucose", "BloodPressure", "SkinThickness",
    "Insulin", "BMI", "DiabetesPedigreeFunction", "Age"
]

# Define realistic ranges for each feature
feature_params = {
    "Pregnancies": dict(min_value=0, max_value=20, step=1, help="Number of times pregnant (0–17+)"),
    "Glucose": dict(min_value=50, max_value=250, step=1, help="Plasma glucose concentration in mg/dL (50–200)"),
    "BloodPressure": dict(min_value=35, max_value=130, step=1, help="Diastolic blood pressure (mm Hg, 35–122)"),
    "SkinThickness": dict(min_value=7, max_value=99, step=1, help="Triceps skin fold thickness (mm, 7–99)"),
    "Insulin": dict(min_value=15, max_value=900, step=1, help="2-Hour serum insulin (µU/mL, 15–846)"),
    "BMI": dict(min_value=18.0, max_value=67.0, step=0.1, help="Body Mass Index (kg/m², 18–67)"),
    "DiabetesPedigreeFunction": dict(min_value=0.05, max_value=2.5, step=0.01, help="Diabetes pedigree function (0.05–2.5)"),
    "Age": dict(min_value=18, max_value=90, step=1, help="Age in years (18–90)"),
}

# Get user input with validation and tooltips
input_data = []
for feature in features:
    value = st.number_input(
        f"{feature}",
        **feature_params[feature]
    )
    input_data.append(value)

if st.button("Predict"):
    # Convert to array, reshape and scale
    input_array = np.array(input_data).reshape(1, -1)
    input_scaled = scaler.transform(input_array)

    # Predict
    prediction = model.predict(input_scaled)[0]
    probability = model.predict_proba(input_scaled)[0][1]

    if prediction == 1:
        st.error(f"⚠️ The model predicts a **HIGH risk** of diabetes. (Probability: {probability:.2f})")
    else:
        st.success(f"✅ The model predicts a **LOW risk** of diabetes. (Probability: {probability:.2f})")